import { GoogleGenAI } from "@google/genai";
import { AnalysisResult, LayerType, StackLayerData, Source } from "../types.ts";

export const analyzeClaim = async (claim: string, apiKey: string): Promise<AnalysisResult> => {
  if (!apiKey) {
    throw new Error("API Key is missing.");
  }

  // Debug check to ensure SDK loaded correctly
  if (typeof GoogleGenAI === 'undefined') {
      console.error("GoogleGenAI SDK failed to load. Please check your internet connection or import map.");
      throw new Error("AI SDK not loaded");
  }

  const ai = new GoogleGenAI({ apiKey: apiKey });

  const prompt = `
    You are TruthStack, an analysis engine.
    Analyze the claim: "${claim}".
    
    **INSTRUCTIONS**:
    1. Perform a deep search to verify facts.
    2. Format your response using **STRICT XML TAGS**.
    
    **OUTPUT FORMAT**:
    
    <investigation>
    Use RICH MARKDOWN here.
    - Start with a header "### 🔍 The Deep Dive"
    - Use bullet points for key facts.
    - Use **bold** for emphasis.
    - If there is numerical data, YOU MUST CREATE A MARKDOWN TABLE.
    - Structure it into clear subsections.
    - Do NOT include the final verdict here.
    </investigation>
    
    <verdict>
    [Level 3 Content: ONE word status (TRUE/FALSE/MISLEADING) followed by 2-3 short summary sentences.]
    </verdict>

    <questions>
    Generate 3 short, intriguing follow-up questions a user might ask next.
    Format:
    <q>Question 1?</q>
    <q>Question 2?</q>
    <q>Question 3?</q>
    </questions>
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });

    let text = response.text || "";
    
    // Clean up code blocks if the model wrapped the XML
    text = text.replace(/```xml/g, '').replace(/```/g, '');

    // 1. Parse XML Sections using Regex
    const investigationMatch = text.match(/<investigation>([\s\S]*?)<\/investigation>/i);
    const verdictMatch = text.match(/<verdict>([\s\S]*?)<\/verdict>/i);
    
    // Parse Questions
    const questionsMatch = text.match(/<questions>([\s\S]*?)<\/questions>/i);
    const suggestedQuestions: string[] = [];
    if (questionsMatch) {
        const qContent = questionsMatch[1];
        const qRegex = /<q>(.*?)<\/q>/g;
        let match;
        while ((match = qRegex.exec(qContent)) !== null) {
            suggestedQuestions.push(match[1].trim());
        }
    }

    let investigationContent = investigationMatch ? investigationMatch[1].trim() : "Analysis pending...";
    let verdictContent = verdictMatch ? verdictMatch[1].trim() : "Verdict pending...";
    
    // 2. Extract Sources
    const sources: Source[] = [];
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    
    if (chunks) {
      chunks.forEach((chunk: any) => {
        if (chunk.web?.uri && chunk.web?.title) {
          sources.push({
            title: chunk.web.title,
            uri: chunk.web.uri
          });
        }
      });
    }

    const layers: StackLayerData[] = [
        {
            id: 'layer-claim',
            type: LayerType.CLAIM,
            title: 'The Claim',
            content: claim,
            isLoading: false
        },
        {
            id: 'layer-investigation',
            type: LayerType.INVESTIGATION,
            title: 'The Investigation',
            content: investigationContent,
            isLoading: false
        },
        {
            id: 'layer-verdict',
            type: LayerType.VERDICT,
            title: 'The Verdict',
            content: verdictContent,
            isLoading: false
        }
    ];

    return { layers, sources, suggestedQuestions };

  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    throw error;
  }
};