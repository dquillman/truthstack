import React from 'react';
// This component is deprecated as bias features have been removed.
export const BiasGraph: React.FC<any> = () => {
  return null;
};