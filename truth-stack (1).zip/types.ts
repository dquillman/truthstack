export interface Source {
  title: string;
  uri: string;
}

export enum LayerType {
  CLAIM = 'claim',
  INVESTIGATION = 'investigation',
  VERDICT = 'verdict',
}

export interface StackLayerData {
  id: string;
  type: LayerType;
  title: string;
  content: string;
  isLoading: boolean;
}

export interface AnalysisResult {
  layers: StackLayerData[];
  sources: Source[];
  suggestedQuestions?: string[];
}
